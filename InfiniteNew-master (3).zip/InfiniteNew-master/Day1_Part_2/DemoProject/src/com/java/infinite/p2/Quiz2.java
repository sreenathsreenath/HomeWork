package com.java.infinite.p2;

public class Quiz2 {

	public static void main(String[] args) {
		String s1="Raghuvir", s2="Raghuvir",s3="Prithvi",s4="Raghuvir";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		
	}
}
