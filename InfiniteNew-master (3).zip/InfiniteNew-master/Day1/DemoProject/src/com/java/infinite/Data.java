package com.java.infinite;

public class Data {

	public void aishwarya() {
		System.out.println("Hi I am Aishwarya...");
	}
	
	private void akash() {
		System.out.println("Hi I am Akash S Tonse...");
	}
	
	void harshit() {
		System.out.println("Hi I am Harshit...");
	}
}
