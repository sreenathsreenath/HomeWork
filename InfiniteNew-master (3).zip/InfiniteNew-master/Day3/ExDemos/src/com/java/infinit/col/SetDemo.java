package com.java.infinit.col;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set s = new HashSet();
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		for (Object ob : s) {
			System.out.println(ob);
		}
	}
}
