package com.java.infinite.employ;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
