package com.java.infinite.employ;

public enum Gender {
	MALE, FEMALE
}
