package com.java.ex;

import java.util.Scanner;

public class Scan2 {

	public static void main(String[] args) {
		int a,b,c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 Numbers    ");
		a=sc.nextInt();
		b=sc.nextInt();
		c=a+b;
		System.out.println("Sum is   " +c);
	}
}
