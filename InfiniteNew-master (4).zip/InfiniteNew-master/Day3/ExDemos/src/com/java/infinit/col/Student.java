package com.java.infinit.col;

public class Student {

	private String firstName;
	private String lastName;
	private String city;
	private double cgp;
}
