package com.java.inventory;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
