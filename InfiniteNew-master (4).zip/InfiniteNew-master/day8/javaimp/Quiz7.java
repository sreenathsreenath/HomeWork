public class Quiz7
{
    public static void main( String[] args )
    {
         int x;
         System.out.println("X value is " +x);      
    }
}
