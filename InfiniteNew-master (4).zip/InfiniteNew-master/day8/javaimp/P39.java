public class P39 {
    static boolean climate;

    public static void main(String[] args) {
        System.out.println(climate);
    }
}
