
public class Quiz12
{
    public static void main( String[] args )
    {
        String[] names=new String[]{"Jintu","Iffat"};
        String s1="Jintu";
        System.out.println(names[0].equals(s1));
    }
}
